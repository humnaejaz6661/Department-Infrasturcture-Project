<?php
$servername = "localhost";
$username = "root";
$password = "mysqlg123";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for insert, update, delete
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['insert']) || isset($_POST['update']) || isset($_POST['delete'])) {
        $id = $_POST['staff-id'];
        $first_name = $_POST['first-name'];
        $last_name = $_POST['last-name'];
        $gender = $_POST['gender'];
        $salary = $_POST['salary'];
        $email = $_POST['email'];

        if (isset($_POST['insert'])) {
            $sql = "INSERT INTO staff (id, first_name, last_name, gender, salary, email) VALUES ('$id', '$first_name', '$last_name', '$gender', '$salary', '$email')";
        } elseif (isset($_POST['update'])) {
            $sql = "UPDATE staff SET first_name='$first_name', last_name='$last_name', gender='$gender', salary='$salary', email='$email' WHERE id='$id'";
        } elseif (isset($_POST['delete'])) {
            $sql = "DELETE FROM staff WHERE id='$id'";
        }

        if (isset($sql)) {
            $tt = $conn->query($sql);
            if ($tt === TRUE) {
                echo "Operation successful";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "No operation selected.";
        }
    }

    // Handle search
    if (isset($_POST['search'])) {
        $id = $_POST['staff-id'];
        $sql = "SELECT * FROM staff WHERE id='$id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $first_name = $row['first_name'];
            $last_name = $row['last_name'];
            $gender = $row['gender'];
            $salary = $row['salary'];
            $email = $row['email'];
            echo "First Name: " . $first_name . "<br>Last Name: " . $last_name . "<br>Gender: " . $gender . "<br>Salary: " . $salary . "<br>Email: " . $email;
        } else {
            echo "0 results";
        }
    }
}

$conn->close();
?>
