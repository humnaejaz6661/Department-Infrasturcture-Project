<?php
$servername = "localhost";
$username = "root";
$password = "mysqlg123";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['classroomNo']) && isset($_POST['advisorId']) && isset($_POST['section']) && isset($_POST['totalStudents'])) {
        $classroomNo = $_POST['classroomNo'];
        $advisorId = $_POST['advisorId'];
        $section = $_POST['section'];
        $totalStudents = $_POST['totalStudents'];

        // Insert operation
        $sql = "INSERT INTO classrooms (classroomNo, advisorId, section, totalStudents) VALUES ('$classroomNo', '$advisorId', '$section', $totalStudents)";

        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Handle delete operation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $classroomNo = $_POST['classroomNo'];

    $sql = "DELETE FROM classrooms WHERE classroomNo='$classroomNo'";

    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Handle update operation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $classroomNo = $_POST['classroomNo'];
    $advisorId = $_POST['advisorId'];
    $section = $_POST['section'];
    $totalStudents = $_POST['totalStudents'];

    $sql = "UPDATE classrooms SET advisorId='$advisorId', section='$section', totalStudents=$totalStudents WHERE classroomNo='$classroomNo'";

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Handle search operation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])) {
    $classroomNo = $_POST['classroomNo'];

    $sql = "SELECT * FROM classrooms WHERE classroomNo='$classroomNo'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "Classroom No: " . $row["classroomNo"]. " - Advisor ID: " . $row["advisorId"]. " - Section: " . $row["section"]. " - Total Students: " . $row["totalStudents"]. "<br>";
        }
    } else {
        echo "0 results";
    }
}

$conn->close();
?>
