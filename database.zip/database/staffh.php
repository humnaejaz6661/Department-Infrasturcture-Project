<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Information Form</title>
    <style>
        body {
            font-family: "Poppins", sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url('images/staff.jpg') no-repeat;
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 420px;
            background: rgba(255, 255, 255, 0.8); /* Transparent background */
            border: 2px solid black;
            backdrop-filter: blur(9px);
            color: #000;
            border-radius: 12px;
            padding: 30px 40px;
        }

        .container h1 {
            font-size: 36px;
            text-align: center;
            margin-bottom: 30px;
        }

        .form-group {
            position: relative;
            width: 100%;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"], input[type="email"], select {
            width: 90%;
            height: 50px;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid black;
            border-radius: 40px;
            font-size: 16px;
            color: #000;
            padding: 0 20px;
        }

        .button-group {
            display: flex;
            justify-content: space-between;
        }

        button {
            width: 24%;
            padding: 10px;
            background-color: #fff;
            color: #333;
            border: none;
            border-radius: 40px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            box-shadow: 0 0 10px rgba(0, 0, 0, .1);
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #f3f3f3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Staff Information Form</h1>
        <form id="staffForm" action="staff.php" method="post">
            <div class="form-group">
                <label for="staff-id">Staff ID:</label>
                <input type="text" id="staff-id" name="staff-id" required>
            </div>
            <div class="form-group">
                <label for="first-name">First Name:</label>
                <input type="text" id="first-name" name="first-name" required>
            </div>
            <div class="form-group">
                <label for="last-name">Last Name:</label>
                <input type="text" id="last-name" name="last-name" required>
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label>
                <select id="gender" name="gender" required>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
            </div>
            <div class="form-group">
                <label for="room-no">Room No:</label>
                <select id="room-no" name="room-no" required>
                    <!-- Options will be populated by PHP -->
                    <?php
                        ini_set('display_errors', 1);
                        ini_set('display_startup_errors', 1);
                        error_reporting(E_ALL);

                        $hostname = "localhost"; // or "127.0.0.1"
                        $username = "root";
                        $password = "mysqlg123";
                        $database = "project";

                        // Connect to MySQL database
                        $conn = new mysqli($hostname, $username, $password, $database);

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Fetch room numbers
                        $sql = "SELECT staffroom_id FROM staffroom";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            // Output data of each row
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row["staffroom_id"] . "'>" . $row["staffroom_id"] . "</option>";
                            }
                        } else {
                            echo "<option value=''>No rooms available</option>";
                        }
                            // Close connection
                            $conn->close();
                     ?> 
                </select>
            </div>
            <div class="form-group">
                <label for="salary">Salary:</label>
                <input type="number" id="salary" name="salary" required>
            </div>
            <div class="form-group">
                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="button-group">
                <button type="submit" name="insert">Insert</button>
                <button type="submit" class="delete" name="delete">Delete</button>
                <button type="submit" class="update" name="update">Update</button>
            </div>
        </form>

        <h1>Search Staff</h1>
        <form id="searchForm" action="staff.php" method="post">
            <div class="form-group">
                <label for="search-staff-id">Staff ID:</label>
                <input type="text" id="search-staff-id" name="staff-id" required>
            </div>
            <div class="button-group">
                <button type="submit" class="search" name="search">Search</button>
            </div>
        </form>
    </div>
</body>
</html>
