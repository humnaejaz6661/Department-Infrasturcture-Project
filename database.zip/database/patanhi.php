<?php
// Database connection parameters
$hostname = "localhost"; // or "127.0.0.1"
$username = "root";
$password = "mysqlg123";
$database = "project";

// Connect to MySQL database
$mysqli = new mysqli($hostname, $username, $password, $database);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// CRUD operations
if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $staffroom_id = $_POST['staffroom_id'];
    $name = $_POST['name'];
    $location = $_POST['location'];
    $capacity = $_POST['capacity'];

    switch ($action) {
        case 'Insert':
            $sql = "INSERT INTO staffroom (staffroom_id, name, location, capacity) VALUES ('$staffroom_id', '$name', '$location', '$capacity')";
            if ($mysqli->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $mysqli->error;
            }
            break;

        case 'Search':
            $sql = "SELECT * FROM staffroom WHERE staffroom_id='$staffroom_id'";
            $result = $mysqli->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "Staffroom ID: " . $row["staffroom_id"]. " - Name: " . $row["name"]. " - Location: " . $row["location"]. " - Capacity: " . $row["capacity"]. "<br>";
                }
            } else {
                echo "0 results";
            }
            break;

        case 'Update':
            $sql = "UPDATE staffroom SET name='$name', location='$location', capacity='$capacity' WHERE staffroom_id='$staffroom_id'";
            if ($mysqli->query($sql) === TRUE) {
                echo "Record updated successfully";
            } else {
                echo "Error updating record: " . $mysqli->error;
            }
            break;

        case 'Delete':
            $sql = "DELETE FROM staffroom WHERE staffroom_id='$staffroom_id'";
            if ($mysqli->query($sql) === TRUE) {
                echo "Record deleted successfully";
            } else {
                echo "Error deleting record: " . $mysqli->error;
            }
            break;
    }
}

// Close database connection
$mysqli->close();
?>
