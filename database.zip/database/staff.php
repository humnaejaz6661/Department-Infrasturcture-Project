<?php
$servername = "localhost";
$username = "root";
$password = "mysqlg123";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for insert, update, delete
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['insert']) || isset($_POST['update']) || isset($_POST['delete'])) {
        $id = $_POST['staff-id'];
        $first_name = $_POST['first-name'];
        $last_name = $_POST['last-name'];
        $gender = $_POST['gender'];
        $room_no = $_POST['room-no'];
        $salary = $_POST['salary'];
        $email = $_POST['email'];

        if (isset($_POST['insert'])) {
            $sql = "INSERT INTO staff (id, first_name, last_name, gender, room_no, salary, email) VALUES ('$id', '$first_name', '$last_name', '$gender', '$room_no', '$salary', '$email')";
        } elseif (isset($_POST['update'])) {
            $sql = "UPDATE staff SET first_name='$first_name', last_name='$last_name', gender='$gender', room_no='$room_no', salary='$salary', email='$email' WHERE id='$id'";
        } elseif (isset($_POST['delete'])) {
            $sql = "DELETE FROM staff WHERE id='$id'";
        }

        if (isset($sql)) {
            if ($conn->query($sql) === TRUE) {
                echo "Operation successful";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "No operation selected.";
        }
    }
// Handle search
if (isset($_POST['search'])) {
    $id = $_POST['staff-id'];
    $sql = "SELECT s.*, sr.name AS room_name, sr.location AS room_location FROM staff s JOIN staffroom sr ON s.room_no = sr.staffroom_id WHERE s.id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $first_name = $row['first_name'];
        $last_name = $row['last_name'];
        $gender = $row['gender'];
        $room_no = $row['room_no'];
        $salary = $row['salary'];
        $email = $row['email'];
        $room_name = $row['room_name'];                                                                                                                //  <!--"<br> <h2>Room dital</h2>".-->                               
        $room_location = $row['room_location'];
        echo "First Name: " . $first_name . "<br>Last Name: " . $last_name . "<br>Gender: " . $gender . "<br>Salary: " . $salary . "<br>Email: " . $email. "<br>Room No: " . $room_no  . "<br>Room Name: " . $room_name . "<br>Room Location: " . $room_location;
    } else {
        echo "0 results";
    }
}
}

$conn->close();
?>
