<?php
$servername = "localhost";
$username = "root"; // Use your MySQL username
$password = "mysqlg123"; // Use your MySQL password
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function insertRecord($conn, $assistantId, $labNo, $labName) {
    $stmt = $conn->prepare("INSERT INTO lab (assistant_id, lab_no, lab_name) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $assistantId, $labNo, $labName);
    $stmt->execute();
    $stmt->close();
}

function deleteRecord($conn, $labNo) {
    $stmt = $conn->prepare("DELETE FROM lab WHERE lab_no = ?");
    $stmt->bind_param("s", $labNo);
    $stmt->execute();
    $stmt->close();
}

function updateRecord($conn, $assistantId, $labNo, $labName) {
    $stmt = $conn->prepare("UPDATE lab SET assistant_id = ?, lab_name = ? WHERE lab_no = ?");
    $stmt->bind_param("sss", $assistantId, $labName, $labNo);
    $stmt->execute();
    $stmt->close();
}

function searchRecord($conn, $labNo) {
    $stmt = $conn->prepare("SELECT * FROM lab WHERE lab_no = ?");
    $stmt->bind_param("s", $labNo);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    return $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST["action"];
    $assistantId = isset($_POST["assistantId"]) ? $_POST["assistantId"] : null;
    $labNo = isset($_POST["labNo"]) ? $_POST["labNo"] : null;
    $labName = isset($_POST["labName"]) ? $_POST["labName"] : null;

    switch ($action) {
        case "insert":
            insertRecord($conn, $assistantId, $labNo, $labName);
            echo "Record inserted successfully";
            break;
        case "delete":
            deleteRecord($conn, $labNo);
            echo "Record deleted successfully";
            break;
        case "update":
            updateRecord($conn, $assistantId, $labNo, $labName);
            echo "Record updated successfully";
            break;
        case "search":
            $record = searchRecord($conn, $labNo);
            echo json_encode($record);
            break;
    }
}

$conn->close();
?>
